<table id="footer">

<tr>






<td>
<b>
For any queries mail us at - events.riviera2015@gmail.com
</b>
</td>



</tr>

</table>

