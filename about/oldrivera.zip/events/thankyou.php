<?php 
echo "Thankyou will revert back to you";
?>