<?php 
$con=mysql_connect("localhost","riviera_riviera","vitriviera");
mysql_select_db("riviera_riviera",$con);
   ?>